require 'sketchup.rb'

Sketchup.send_action("showRubyPanel:")

# entities.each { |e| e.erase! }

def circle(radius, count)
  edges = entities.add_circle(origin, z_axis, radius, count)
  edges.each do |edge|
    c = entities.add_circle(edge.start, z_axis, (3).mm)
    # entities.add_face(c)
    edge.erase!
  end
end

def entities
  Sketchup.active_model.entities
end

def origin
  Geom::Point3d.new
end

def z_axis
  Geom::Vector3d.new(0, 0, 1).normalize!
end

# 5
# circle(25.mm, 15)
# circle(35.mm, 20)
# circle(45.mm, 25)
# circle(55.mm, 30)
# circle(65.mm, 35)

# 6
# circle(25.mm, 18)
# circle(35.mm, 24)
# circle(45.mm, 30)
# circle(55.mm, 36)
# circle(65.mm, 42)

# 7
def holes
  circle(25.mm, 14)
  circle((34.5).mm, 21)
  circle(44.mm, 28)
  circle((53.5).mm, 35)
  circle(63.mm, 42)
end

# 8
# circle(25.mm, 16)
# circle(35.mm, 24)
# circle(45.mm, 32)
# circle(55.mm, 40)
# circle(65.mm, 48)

